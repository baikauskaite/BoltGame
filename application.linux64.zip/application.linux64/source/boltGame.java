import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class boltGame extends PApplet {

/**
    
    "The Bolt Rush"

    The first object-oriented programming project.
    The sprite is moved around by arrow keys.
    The objective of the game is to reach the "Bolt" truck.

    @author  Viktorija Baikauskaitė, 4 gr.
    
*/

// Maps
Map baseMapSky;
Map baseMapBuildings1;
Map baseMapBuildings2;
Map baseMapGround;
Map worldLevel1;
Map worldLevel2;
Map worldLevel3;

// Buttons
int currentTileId;
Object tilemapTiles[];
int tilemapTilesNumber;
Object editedMapTiles[];
Object playButton;
Object editMapButton;
Object quitButton;
Object levelButton;
Object levelButtonLeft;
Object levelButtonRight;
Object editedMapButtonRight;
Object editedMapButtonLeft;
Object eraserButton;
Object backToMenuButton;
Object saveButton;
Object backToMenuFromPlayButton;
Object statusLives;
Object statusLivesNumber;
Object statusPoints;
Object statusPointsNumber;

// Player
Player corgi;
// Corgi player images
PImage walkingImages[];
int numberWalkingImages;
PImage jumpingImages[];
int numberJumpingImages;
int standingImage = 0;
PImage dyingImages[];
int numberDyingImages;

// Colors and fonts
PFont font, title;
int menuBackgroundColor;
int buttonsPressedColor;
int textColor;

// Game states
String gameState;
String levelState;

// Player camera offset
int cameraOffsetX;
int cameraOffsetY;

// Map editor properties
int tilemapX, tilemapY;
int editedMapX, editedMapY;
int editedMapColumns, editedMapRows;
int beginEditedMapColumn, endEditedMapColumn;
String editLevelNumber;
boolean erasingMode;
JSONObject json;
Table table;
PImage imageDrag;

// Enemy properties
PImage boltImage;
PImage woltImage;
Object woltBoxes[];
int woltBoxesNumber;
PImage woltBoxImage;

// Game properties
int livesLeft;
int hurt;
boolean isHurt;
int points;
int screenMessageTime;
int level2Introduction, level3Introduction;
int currentImage;
boolean doNotChangeLevel;
boolean left, right, up, down;

public void setup(){
  
  // Game properties
  hurt = 0;
  livesLeft = 5;
  level2Introduction = 150;
  level3Introduction = 100;
  currentImage = 0;
  doNotChangeLevel = false;
  boltImage = loadImage("data/bolt.png");
  woltImage = loadImage("data/wolt.png");
  
  // Setting the gameState
  gameState = "MENU";
  levelState = "LEVEL 1";

  // Map editor properties
  tilemapX = 700;
  tilemapY = 200;
  editedMapX = 80;
  editedMapY = 50;
  editedMapColumns = 25;
  editedMapRows = 20;
  beginEditedMapColumn = 0;
  endEditedMapColumn = 25;
  editLevelNumber = "LEVEL 1";
  imageDrag = new PImage();
  erasingMode = false;
  screenMessageTime = 150;
  
  // Background
  
  background(255);
  
  // Player camera offset
  cameraOffsetX = 0;
  cameraOffsetY = 0;
  
  // Loading corgi player images
  numberWalkingImages = 10;
  walkingImages = new PImage[numberWalkingImages];
  for (int i = 0; i < numberWalkingImages; ++i) {
    walkingImages[i] = loadImage("data/corgi/Walk ("+ (i+1) +").png");
  }
  numberJumpingImages = 8;
  jumpingImages = new PImage[numberJumpingImages];
  for (int i = 0; i < numberJumpingImages; ++i) {
    jumpingImages[i] = loadImage("data/corgi/Jump ("+ (i+1) +").png");
  }
  numberDyingImages = 10;
  dyingImages = new PImage[numberDyingImages];
  for (int i = 0; i < numberDyingImages; ++i) {
    dyingImages[i] = loadImage("data/corgi/Dead ("+ (i+1) +").png");
  }
  
  // Creating enemies
  woltBoxesNumber = 2;
  woltBoxes = new Object[woltBoxesNumber];
  woltBoxes[0] = new Object();
  woltBoxes[0].x = random(100, 200);
  woltBoxes[0].y = random(100, 200);
  woltBoxes[1] = new Object();
  woltBoxes[1].x = random(400, 800);
  woltBoxes[1].y = random(600, 800);
  woltBoxImage = new PImage();
  woltBoxImage = loadImage("data/wolt_box.png");

  table = loadTable("data/map/baseMap_sky.csv");
  json = loadJSONObject("data/tileset/cityBackground.json");
  baseMapSky = new Map();
  table = loadTable("data/map/baseMap_buildings1.csv");
  baseMapBuildings1 = new Map(); 
  table = loadTable("data/map/baseMap_buildings2.csv");
  baseMapBuildings2 = new Map();
  table = loadTable("data/map/baseMap_ground.csv");
  json = loadJSONObject("data/tileset/cityObjects.json");
  baseMapGround = new Map();
  table = loadTable("data/map/world_level1.csv");
  worldLevel1 = new Map();
  table = loadTable("data/map/world_level2.csv");
  worldLevel2 = new Map();
  table = loadTable("data/map/world_level3.csv");
  worldLevel3 = new Map();
  
  baseMapSky.tileIdTable = loadTable("data/map/baseMap_sky.csv");
  baseMapBuildings1.tileIdTable = loadTable("data/map/baseMap_buildings1.csv");
  baseMapBuildings2.tileIdTable = loadTable("data/map/baseMap_buildings2.csv");
  baseMapGround.tileIdTable = loadTable("data/map/baseMap_ground.csv");
  worldLevel1.tileIdTable = loadTable("data/map/world_level1.csv");
  worldLevel2.tileIdTable = loadTable("data/map/world_level2.csv");
  worldLevel3.tileIdTable = loadTable("data/map/world_level3.csv");
  
  // Loading the map images
  baseMapSky.tilesetImage = loadImage("data/tileset/cityBackground.png");
  baseMapBuildings1.tilesetImage = loadImage("data/tileset/cityBackground.png");
  baseMapBuildings2.tilesetImage = loadImage("data/tileset/cityBackground.png");
  baseMapGround.tilesetImage = loadImage("data/tileset/cityObjects.png");
  worldLevel1.tilesetImage = loadImage("data/tileset/cityObjects.png");
  worldLevel2.tilesetImage = loadImage("data/tileset/cityObjects.png");
  worldLevel3.tilesetImage = loadImage("data/tileset/cityObjects.png");
  
  baseMapSky.tilesetProperties = loadJSONObject("data/tileset/cityBackground.json");
  baseMapBuildings1.tilesetProperties = loadJSONObject("data/tileset/cityBackground.json");
  baseMapBuildings2.tilesetProperties = loadJSONObject("data/tileset/cityBackground.json");
  baseMapGround.tilesetProperties = loadJSONObject("data/tileset/cityObjects.json");
  worldLevel1.tilesetProperties = loadJSONObject("data/tileset/cityObjects.json");
  worldLevel2.tilesetProperties = loadJSONObject("data/tileset/cityObjects.json");
  worldLevel3.tilesetProperties = loadJSONObject("data/tileset/cityObjects.json");
   
  // Initializing buttons
  playButton = new Object();
  playButton.beginX = width/2-100;
  playButton.beginY = height/2-30;
  playButton.endX = width/2+100;
  playButton.endY = height/2+30;
  editMapButton = new Object();
  editMapButton.beginX = width/2-100;
  editMapButton.beginY = height/2+70;
  editMapButton.endX = width/2+100;
  editMapButton.endY = height/2+130;
  quitButton = new Object();
  quitButton.beginX = width/2-100;
  quitButton.beginY = height/2+170;
  quitButton.endX = width/2+100;
  quitButton.endY = height/2+230;
  levelButton = new Object();
  levelButton.beginX = tilemapX;
  levelButton.beginY = tilemapY-100;
  levelButton.endX = tilemapX+240;
  levelButton.endY = tilemapY+60-100;
  levelButtonLeft = new Object();
  levelButtonLeft.beginX = tilemapX;
  levelButtonLeft.beginY = tilemapY-100;
  levelButtonLeft.endX = tilemapX+30;
  levelButtonLeft.endY = tilemapY+60-100;
  levelButtonRight = new Object();
  levelButtonRight.beginX = tilemapX+210;
  levelButtonRight.beginY = tilemapY-100;
  levelButtonRight.endX = tilemapX+240;
  levelButtonRight.endY = tilemapY+60-100;
  editedMapButtonLeft = new Object();
  editedMapButtonLeft.beginX = editedMapX - 40;
  editedMapButtonLeft.beginY = editedMapY + editedMapRows*(worldLevel1.tileHeight/2)/2 - 30;
  editedMapButtonLeft.endX = editedMapX - 10;
  editedMapButtonLeft.endY = editedMapY + editedMapRows*(worldLevel1.tileHeight/2)/2 + 30;
  editedMapButtonRight = new Object();
  editedMapButtonRight.beginX = editedMapX + editedMapColumns*(worldLevel1.tileWidth/2) + 10;
  editedMapButtonRight.beginY = editedMapY + editedMapRows*(worldLevel1.tileHeight/2)/2 - 30;
  editedMapButtonRight.endX = editedMapX + editedMapColumns*(worldLevel1.tileWidth/2) + 40;
  editedMapButtonRight.endY = editedMapY + editedMapRows*(worldLevel1.tileHeight/2)/2 + 30;
  eraserButton = new Object();
  eraserButton.beginX = width/2 + 200;
  eraserButton.beginY = editedMapY + editedMapRows*(worldLevel1.tileHeight/2) + 100;
  eraserButton.endX = width/2 + 400;
  eraserButton.endY = editedMapY + editedMapRows*(worldLevel1.tileHeight/2) + 160;
  backToMenuButton = new Object();
  backToMenuButton.beginX = width/2 - 400;
  backToMenuButton.beginY = editedMapY + editedMapRows*(worldLevel1.tileHeight/2) + 100;
  backToMenuButton.endX = width/2 - 200;
  backToMenuButton.endY = editedMapY + editedMapRows*(worldLevel1.tileHeight/2) + 160;
  saveButton = new Object();
  saveButton.beginX = width/2 - 100;
  saveButton.beginY = editedMapY + editedMapRows*(worldLevel1.tileHeight/2) + 100;
  saveButton.endX = width/2 + 100;
  saveButton.endY = editedMapY + editedMapRows*(worldLevel1.tileHeight/2) + 160;
  backToMenuFromPlayButton = new Object();
  backToMenuFromPlayButton.beginX = 30;
  backToMenuFromPlayButton.beginY = 30;
  backToMenuFromPlayButton.endX = 70;
  backToMenuFromPlayButton.endY = 70;
  statusLives = new Object();
  statusLives.beginX = 600;
  statusLives.beginY = 40;
  statusLives.endX = 720;
  statusLives.endY = 80;
  statusLivesNumber = new Object();
  statusLivesNumber.beginX = 720;
  statusLivesNumber.beginY = 40;
  statusLivesNumber.endX = 770;
  statusLivesNumber.endY = 80;
  statusPoints = new Object();
  statusPoints.beginX = 770;
  statusPoints.beginY = 40;
  statusPoints.endX = 890;
  statusPoints.endY = 80;
  statusPointsNumber = new Object();
  statusPointsNumber.beginX = 890;
  statusPointsNumber.beginY = 40;
  statusPointsNumber.endX = 940;
  statusPointsNumber.endY = 80;
  
  // Tilemap tiles
  tilemapTilesNumber = worldLevel1.imageRows * worldLevel1.imageColumns;
  tilemapTiles = new Object[tilemapTilesNumber];
  for (int i = 0; i < tilemapTilesNumber; ++i) {
   tilemapTiles[i] = new Object();
  }
  worldLevel1.createTiles();
  editedMapTiles = new Object[editedMapColumns*editedMapRows];
  for (int i = 0; i < editedMapColumns*editedMapRows; ++i) {
    editedMapTiles[i] = new Object();
  }
  worldLevel1.createEditedMapTiles();
  
  // Setting the default font
  font = createFont("data/font/Minecraft.ttf", 32);
  textFont(font);
  title = createFont("data/font/sttransmission-800-extrabold.otf", 140);
  
  // Setting the default colors
  menuBackgroundColor = color(0, 211, 117);
  buttonsPressedColor = color(72, 125, 101);
  textColor = color(255);
  
  // Initializing the player corgi
  corgi = new Player();
  
  // Setting boolean variables to false
  left = false;
  right = false;
  up = false;
  down = false;
}

public void draw() {
  
  if (gameState == "MENU") {
    menuGame();
  }
  else if (gameState == "EDIT") {
    editGame();
  }
  else if (gameState == "PLAY") {
    playGame();
  }
  else if (gameState == "QUIT") {
    exit();
  }
}

public void keyPressed() {
  
  switch(keyCode) {
  case 37: // left
    left = true;
    break;
   case 38: // up
    up = true;
    break;
   case 32: // up (space)
    up = true;
    break;
   case 39: // right
    right = true;
    break;
   case 40: // down
    down = true;
  }
  
}

public void keyReleased() {
  
    switch(keyCode) {
  case 37: // left
    left = false;
    break;
   case 38: // up
    up = false;
    break;
   case 32: // up (space)
    up = false;
    break;
   case 39: // right
    right = false;
    break;
   case 40: // down
    down = false;
  }
  
}

public void clearBackground() {
  background(40, 46, 150);
}

public void menuGame() {
  
  // Name of the game
  scale(1.0f);
  background(menuBackgroundColor);
  textSize(80);
  textAlign(CENTER, CENTER);
  fill(textColor);
  textFont(title);
  text ("THE", width/2-300, height/2 - 130);
  text ("RUSH", width/2+300, height/2 - 130);
  textFont(font);
  imageMode(CENTER);
  pushMatrix();
  scale(0.8f);
  imageMode(CENTER);
  image(boltImage, width-400, height-440);
  popMatrix();
  
  // Menu buttons
  playButton.button("PLAY", 30);
  editMapButton.button("EDIT MAP", 30);
  quitButton.button("QUIT", 30);
  
  if (playButton.isMouseTouching() == true) {
    playButton.mouseTouchingButton("PLAY", 30);
    if (mousePressed)
      gameState = "PLAY";
  }
  if (editMapButton.isMouseTouching() == true) {
    editMapButton.mouseTouchingButton("EDIT MAP", 30);
    if (mousePressed)
      gameState = "EDIT";
  }
  if (quitButton.isMouseTouching() == true) {
    quitButton.mouseTouchingButton("QUIT", 30);
    if (mousePressed)
      gameState = "QUIT";
  }
  
}

// PLAYING THE GAME

public void playGame() {

  clearBackground();
  
  if (levelState == "LEVEL 1") {
    baseMapSky.update();
    baseMapBuildings1.update();
    baseMapBuildings2.update();
    worldLevel1.updateWithObjects();
    corgi.resolvePlatformCollisions(worldLevel1.playMapTiles, worldLevel1.playMapTilesNumber);
    corgi.display();
    screenMessageTime = 150;
    statusLives.button("LIVES", 20);
    statusLivesNumber.button(str(livesLeft), 20);
    statusPoints.button("POINTS", 20);
    statusPointsNumber.button(str(points), 20);
  }
  else if (levelState == "LEVEL 2") {
    if (level2Introduction > 0) {
      background(0, 155, 228);
      textSize(100);
      textAlign(CENTER, CENTER);
      text("BEWARE!", width/2, height/2-200);
      pushMatrix();
      scale(0.8f);
      image(woltImage, width/2+100, height/2+100);
      popMatrix();
      textSize(100);
      textAlign(CENTER, CENTER);
      text("INCOMING", width/2, height/2+200);
      --level2Introduction;
    }
    else {
      doNotChangeLevel = false;
      baseMapSky.update();
      baseMapBuildings1.update();
      baseMapBuildings2.update();
      worldLevel2.updateWithObjects();
      corgi.resolvePlatformCollisions(worldLevel2.playMapTiles, worldLevel2.playMapTilesNumber);
      corgi.display();
      textSize(15);
      statusLives.button("LIVES", 20);
      statusLivesNumber.button(str(livesLeft), 20);
      statusPoints.button("POINTS", 20);
      statusPointsNumber.button(str(points), 20);
      screenMessageTime = 150;
      woltBoxes[0].display(woltBoxImage);
      woltBoxes[0].update();
    }
  }
  else if (levelState == "LEVEL 3") {
    if (level3Introduction > 0) {
      background(0, 155, 228);
      textAlign(CENTER, CENTER);
      textSize(50);
      text("EVEN MORE OF THEM!", width/2, height/2);
      --level3Introduction;
    }
    else {
      baseMapSky.update();
      baseMapBuildings1.update();
      baseMapBuildings2.update();
      worldLevel3.updateWithObjects();
      corgi.resolvePlatformCollisions(worldLevel3.playMapTiles, worldLevel3.playMapTilesNumber);
      corgi.display();
      textSize(15);
      statusLives.button("LIVES", 20);
      statusLivesNumber.button(str(livesLeft), 20);
      statusPoints.button("POINTS", 20);
      statusPointsNumber.button(str(points), 20);
      screenMessageTime = 150;
      woltBoxes[0].display(woltBoxImage);
      woltBoxes[0].update();
      woltBoxes[1].display(woltBoxImage);
      woltBoxes[1].update();
      doNotChangeLevel = false;
    }
  }
  else if (levelState == "LOST") {
    background(menuBackgroundColor);
    if (screenMessageTime > 0) {
      if (screenMessageTime%10 == 0 && currentImage < 9) {
        ++currentImage;
      }
      pushMatrix();
      scale(0.8f);
      imageMode(CENTER);
      image(dyingImages[currentImage%10], width/2-50, height/2+100);
      textAlign(CORNER);
      textSize(100);
      text("YOU LOST", width/2+50, height/2-50);
      popMatrix();
      --screenMessageTime;
    }
    else {
      gameState = "QUIT";
    }
  }
  else if (levelState == "WON") {
      background(menuBackgroundColor);
      if (screenMessageTime > 0) {
      if (screenMessageTime%10 == 0 && currentImage < 7) {
        ++currentImage;
      }
      pushMatrix();
      scale(0.8f);
      imageMode(CENTER);
      image(jumpingImages[currentImage%8], width/2-50, height/2+100);
      textAlign(CORNER);
      textSize(100);
      text("YOU WON!", width/2+50, height/2-50);
      popMatrix();
      --screenMessageTime;
    }
    else {
      gameState = "QUIT";
    }
  }
  
  backToMenuFromPlayButton.button("<", 30);
  
  if (backToMenuFromPlayButton.isMouseTouching() == true) {
    backToMenuFromPlayButton.mouseTouchingButton("<", 30);
    if (mousePressed)
      gameState = "MENU";
  }
}

// TILEMAP EDITOR
  
public void editGame() {

  background(menuBackgroundColor);
  
  baseMapSky.displayInEditMap();
  baseMapBuildings1.displayInEditMap();
  baseMapBuildings2.displayInEditMap();
  baseMapGround.displayInEditMap();

  worldLevel1.displayTileMap();
  
  for (int i = 0; i < tilemapTilesNumber; ++i) {
    if (tilemapTiles[i].isMouseTouching() == true) {
      if (mousePressed == true) {
        int imageWidth = tilemapTiles[i].endX-tilemapTiles[i].beginX;
        int imageHeight = tilemapTiles[i].endY-tilemapTiles[i].beginY;
        imageDrag = worldLevel1.tilesetImage.get(worldLevel1.tileWidth*tilemapTiles[i].idColumn, worldLevel1.tileHeight*tilemapTiles[i].idRow, imageWidth, imageHeight);
        currentTileId = i;
      }
    }
  }
  
  if (editLevelNumber == "LEVEL 2") {
    worldLevel2.displayInEditMap();
    
    for (int i = 0; i < editedMapColumns*editedMapRows; ++i) {
      if (editedMapTiles[i].isMouseTouching() == true) {
        if ( (mousePressed == true) && (erasingMode == false) ) {
          worldLevel2.addTile(i);
        }
        else if ( (erasingMode == true) && (mousePressed == true) ) {
          worldLevel2.deleteTile(i);
        }
      }
    }
  }
  else if (editLevelNumber == "LEVEL 3") {
    worldLevel3.displayInEditMap();
    
    for (int i = 0; i < editedMapColumns*editedMapRows; ++i) {
      if (editedMapTiles[i].isMouseTouching() == true) {
        if ( (mousePressed == true) && (erasingMode == false) ) {
          worldLevel3.addTile(i);
        }
        else if ( (erasingMode == true) && (mousePressed == true) ) {
          worldLevel3.deleteTile(i);
        }
      }
    }
  }
  else {
    worldLevel1.displayInEditMap();
    
    for (int i = 0; i < editedMapColumns*editedMapRows; ++i) {
      if (editedMapTiles[i].isMouseTouching() == true) {
        if ( (mousePressed == true) && (erasingMode == false) ) {
          worldLevel1.addTile(i);
        }
        else if ( (erasingMode == true) && (mousePressed == true) ) {
          worldLevel1.deleteTile(i);
        }
      }
    }
  }
  
  // BUTTONS
  
  levelButton.button(editLevelNumber, 30);
  levelButtonLeft.button("<", 30); 
  levelButtonRight.button(">", 30); 
  editedMapButtonLeft.button("<", 30);
  editedMapButtonRight.button(">", 30);
  eraserButton.button("ERASER", 30);
  backToMenuButton.button("< MENU", 30);
  saveButton.button("SAVE", 30);
  
  if (eraserButton.isMouseTouching() == true) {
    eraserButton.mouseTouchingButton("ERASER", 30);
  }
  
  if (erasingMode == true) {
    eraserButton.mouseTouchingButton("ERASER", 30);
  }
  else {
    image(imageDrag, mouseX, mouseY);
  }
  
  if (saveButton.isMouseTouching() == true) {
    saveButton.mouseTouchingButton("SAVE", 30);
  }
  
  // Go back to menu from the editor
  if (backToMenuButton.isMouseTouching() == true) {
    backToMenuButton.mouseTouchingButton("< MENU", 30);
  }
  
  if (editedMapButtonRight.isMouseTouching() == true) {
      if (endEditedMapColumn < worldLevel1.tileIdTableColumns) {
        editedMapButtonRight.mouseTouchingButton(">", 30);
      }
   }
   
  if (editedMapButtonLeft.isMouseTouching() == true) {
    if (beginEditedMapColumn > 0) {
      editedMapButtonLeft.mouseTouchingButton("<", 30);
    }
  }
   
  
  if (levelButtonRight.isMouseTouching() == true) {
    if (editLevelNumber == "LEVEL 1") {
        levelButtonRight.mouseTouchingButton(">", 30);
     }
     else if (editLevelNumber == "LEVEL 2") {
        levelButtonRight.mouseTouchingButton(">", 30);
     }
  }
  
  if (levelButtonLeft.isMouseTouching() == true) {
     if (editLevelNumber == "LEVEL 2") {
       levelButtonLeft.mouseTouchingButton("<", 30);
     }
     else if (editLevelNumber == "LEVEL 3") {
       levelButtonLeft.mouseTouchingButton("<", 30);
     }
  }
  
}

public void mouseClicked() {

  if (editLevelNumber == "LEVEL 2") {
    if (saveButton.isMouseTouching() == true) {
      saveTable(worldLevel2.tileIdTable, "data/map/world_level2.csv");
    }
    
    if (editedMapButtonRight.isMouseTouching() == true) {
      if (endEditedMapColumn < worldLevel2.tileIdTableColumns) {
        beginEditedMapColumn += 1;
        endEditedMapColumn += 1;
      }
    }
  }
  else if (editLevelNumber == "LEVEL 3") {
    if (saveButton.isMouseTouching() == true) {
      saveTable(worldLevel3.tileIdTable, "data/map/world_level3.csv");
    }
    
    if (editedMapButtonRight.isMouseTouching() == true) {
      if (endEditedMapColumn < worldLevel3.tileIdTableColumns) {
        beginEditedMapColumn += 1;
        endEditedMapColumn += 1;
      }
    }
  }
  else {
    if (saveButton.isMouseTouching() == true) {
      saveTable(worldLevel1.tileIdTable, "data/map/world_level1.csv");
    }
    
    if (editedMapButtonRight.isMouseTouching() == true) {
      if (endEditedMapColumn < worldLevel1.tileIdTableColumns) {
        beginEditedMapColumn += 1;
        endEditedMapColumn += 1;
      }
    }
  }
  
  if (editedMapButtonLeft.isMouseTouching() == true) {
    if (beginEditedMapColumn > 0) {
      beginEditedMapColumn -= 1;
      endEditedMapColumn -= 1;
    }
  }
  
  if (eraserButton.isMouseTouching() == true) {
    if (erasingMode == true) {
      erasingMode = false;
    }
    else {
      erasingMode = true;
    }
  }
  
  if (backToMenuButton.isMouseTouching() == true) {
     gameState = "MENU";
  }
  
  if (levelButtonRight.isMouseTouching() == true) {
    if (editLevelNumber == "LEVEL 1") {
       editLevelNumber = "LEVEL 2";
     }
     else if (editLevelNumber == "LEVEL 2") {
       editLevelNumber = "LEVEL 3";
     }
  }
  
  if (levelButtonLeft.isMouseTouching() == true) {
     if (editLevelNumber == "LEVEL 2") {
       editLevelNumber = "LEVEL 1";
     }
     else if (editLevelNumber == "LEVEL 3") {
       editLevelNumber = "LEVEL 2";
     }
  }
    
}
class Map {
  
  // Properties
  Table tileIdTable;
  PImage tilesetImage;
  JSONObject tilesetProperties;
  int tileIdTableColumns;
  int tileIdTableRows;
  
  int tileId;
  int previousTileId;
  
  int tileX, tileY;
  PImage img;
  
  int tileHeight;
  int tileWidth;
  int imageRows;
  int imageColumns;
  int imageHeight;
  int imageWidth;
  
  Object playMapTiles[];
  int playMapTilesNumber;
  
  // Constructor
  Map () {
    tileId = 1;
    previousTileId = 1000;
    
    tileHeight = json.getInt("tileheight");
    tileWidth = json.getInt("tilewidth");
    imageHeight = json.getInt("imageheight");
    imageRows = imageHeight / tileHeight;
    imageWidth = json.getInt("imagewidth");
    imageColumns = imageWidth / tileWidth;
    
    tileIdTableRows = table.getRowCount();
    tileIdTableColumns = table.getColumnCount();
    
    playMapTilesNumber = tileIdTableColumns * tileIdTableRows;
    playMapTiles = new Object[playMapTilesNumber];
    for (int i = 0; i < playMapTilesNumber; ++i) {
      playMapTiles[i] = new Object();
    }
  }
  
  public void update() {
      
    for (int row = 0; row < tileIdTableRows; ++row) {
      for (int column = 0; column < tileIdTableColumns; ++column) {
        tileId = tileIdTable.getInt(row, column);
         if (tileId == -1)
          continue;
        tileX = tileId % imageColumns;
        tileY = tileId / imageColumns;
        
        img = tilesetImage.get(tileX*tileWidth, tileY*tileHeight, tileWidth, tileHeight);
        imageMode(CORNER);
        image(img, cameraOffsetX + column*tileWidth, cameraOffsetY + row*tileHeight, tileWidth, tileHeight);
      }
    }
  
  }
  
  public void updateWithObjects () {
    
    Object mapTile;
    for (int row = 0; row < tileIdTableRows; ++row) {
      for (int column = 0; column < tileIdTableColumns; ++column) {
        tileId = tileIdTable.getInt(row, column);
        mapTile = playMapTiles[row*tileIdTableColumns+column];
        mapTile.id = tileId;
        
        if (tileId == -1)
          continue;
          
        mapTile.beginX = cameraOffsetX + column*tileWidth;
        mapTile.beginY = cameraOffsetY + row*tileHeight;
        mapTile.endX = cameraOffsetX + column*tileWidth + tileWidth;
        mapTile.endY = cameraOffsetY + row*tileHeight + tileHeight;
        mapTile.idColumn = column;
        mapTile.idRow = row;
        
        tileX = tileId % imageColumns;
        tileY = tileId / imageColumns;
        
        img = tilesetImage.get(tileX*tileWidth, tileY*tileHeight, tileWidth, tileHeight);
        imageMode(CORNER);
        image(img, cameraOffsetX + column*tileWidth, cameraOffsetY + row*tileHeight, tileWidth, tileHeight);
      }
    }
  
  }
  
  public void displayInEditMap () {
    
    noFill();
    strokeWeight(0.5f);
    stroke(191, 191, 191);
    
    int x, y;
    int tWidth = tileWidth/2;
    int tHeight = tileHeight/2;
    
    // Display of the level map
    for (int row = 0; row < editedMapRows; ++row) {
      for (int i = beginEditedMapColumn, column = 0; i < endEditedMapColumn; ++i, ++column) {
        x = editedMapX + column*tWidth;
        y = editedMapY + row*tHeight;
        tileId = tileIdTable.getInt(row, i);
        
        if (tileId == -1) {
          rectMode(CORNER);
          rect(x, y, tWidth, tHeight);
          editedMapTiles[row*editedMapColumns+column].idColumn = i;
          editedMapTiles[row*editedMapColumns+column].idRow = row;
          continue;
        }
        
        editedMapTiles[row*editedMapColumns+column].idColumn = i;
        editedMapTiles[row*editedMapColumns+column].idRow = row;
        
        tileX = tileId % imageColumns;
        tileY = tileId / imageColumns;
        img = tilesetImage.get(tileX*tileWidth, tileY*tileHeight, tileWidth, tileHeight);
        imageMode(CORNER);
        image(img, x, y, tWidth, tHeight);
        rectMode(CORNER);
        rect(x, y, tWidth, tHeight);
      }
    }
  
}

  public void displayTileMap () {
    noFill();
    strokeWeight(1);
    stroke(191, 191, 191);
  
    // display of the tilemap
    for (int row = 0; row < imageRows; ++row) {
      for (int column = 0; column < imageColumns; ++column) {
        img = tilesetImage.get(column*tileWidth, row*tileHeight, tileWidth, tileHeight);
        imageMode(CORNER);
        image(img, tilemapX + column*tileWidth, tilemapY + row*tileHeight, tileWidth, tileHeight);        
        // lines between tiles
        rectMode(CORNER);
        rect(tilemapX + column*tileWidth, tilemapY + row*tileHeight, tileWidth, tileHeight);
       }
    }
    
  
  }
  
  public void createTiles () {
    int index;
    
    for (int row = 0; row < imageRows; ++row) {
      for (int column = 0; column < imageColumns; ++column) {
        index = row*imageColumns+column;
        tilemapTiles[index].beginX = tilemapX + column*tileWidth;
        tilemapTiles[index].beginY = tilemapY + row*tileHeight;
        tilemapTiles[index].endX = tilemapX + column*tileWidth + tileWidth;
        tilemapTiles[index].endY = tilemapY + row*tileHeight + tileHeight;
        tilemapTiles[index].idColumn = column;
        tilemapTiles[index].idRow = row;
       }
    }
  
  }
  
  public void createEditedMapTiles () {
    int index;
    int tWidth = tileWidth/2;
    int tHeight = tileHeight/2;
    
    for (int row = 0; row < editedMapRows; ++row) {
      for (int column = 0; column < editedMapColumns; ++column) {
        index = row*editedMapColumns+column;
        editedMapTiles[index].beginX = editedMapX + column*tWidth;
        editedMapTiles[index].beginY = editedMapY + row*tHeight;
        editedMapTiles[index].endX = editedMapX + column*tWidth + tWidth;
        editedMapTiles[index].endY = editedMapY + row*tHeight + tHeight;
       }
    }
  }
  
  public void addTile (int index) {
    tileIdTable.setInt(editedMapTiles[index].idRow, editedMapTiles[index].idColumn, currentTileId);
  }
  
  public void deleteTile (int index) {
    tileIdTable.setInt(editedMapTiles[index].idRow, editedMapTiles[index].idColumn, -1);
  }
    
  public void deleteTile (Object tile) {
    tileIdTable.setInt(tile.idRow, tile.idColumn, -1);
  }

}
class Object {
  
  // Properties
  int beginX;
  int beginY;
  int endX;
  int endY;
  
  int idColumn;
  int idRow;
  
  int id;
  
  int dx;
  int dy;
  
  int changeDestination;
  float destinationX;
  float destinationY;
  float x, y;
  
  // Constructor
  Object () {
    
  }
  
  public boolean isMouseTouching () {
    if ( (mouseX >= beginX) && (mouseX <= endX) && (mouseY >= beginY) && (mouseY <= endY) )
      return true;
    
    return false;
  }
  
  public void button (String message, int textSize) {
    
    strokeWeight(10);
    stroke(textColor);
    fill(menuBackgroundColor);
    rectMode(CORNERS);
    rect(beginX, beginY, endX, endY);
    displayText(message, textSize);

  }
  
  public void mouseTouchingButton (String message, int textSize) {
    
   fill(buttonsPressedColor);
   rect(beginX, beginY, endX, endY);
   displayText(message, textSize);
   
  }
  
  public void displayText (String message, int textSize) {
    textSize(textSize);
    fill(textColor);
    textAlign(CENTER, CENTER);
    text (message, (beginX+endX)/2, (beginY+endY)/2);
  }
  
  public int getLeft () {
    return (int)beginX;
  }
  public int getRight () {
    return endX;
  }
  public int getTop () {
    return (int)beginY;
  }
  public int getBottom () {
    return endY;
  }
  
  // Enemy display
  
  public void display(PImage img) {
    imageMode(CORNER);
    image(img, x, y);
  }
  
  // Enemy update
  
  public void update() {
    
    if (changeDestination%100 == 0 || x == destinationX || y == destinationY) {
      destinationX = random(0, 1000);
      destinationY = random(0, 700);
    }
    
    if (x < destinationX) {
      x += random(1, 2) - corgi.changeX/2;
    }
    else if (x > destinationX){
      x -= random(1, 2) + corgi.changeX/2;
    }
    if (y < destinationY) {
      y += random(1, 2) - corgi.changeY/4;
    }
    else if (y > destinationY) {
      y -= random(1, 2) + corgi.changeY/4;
    }
    
    beginX = (int)x;
    beginY = (int)y;
    endX = (int)x + 40;
    endY = (int)y + 40;
    
    ++changeDestination;
  }
  
  // Checking whether enemy is touching the player
  
  public boolean isTouching(Player player) {
    
     boolean noXOverlap = player.getRight() < beginX || player.getLeft() > endX;
     boolean noYOverlap = player.getBottom() < beginY || player.getTop() > endY;
     
     if (noXOverlap || noYOverlap) {
       return false;
     }
     else {
       return true;
     }
    
  }
}
class Player {
  
  // Properties
  int x, y; // current position of sprite
  int w, h; // width and height of sprite
  int maxSpeed;
  int posLeft, posRight, posBottom, posTop;
  int currentFrameWalking, currentFrameJumping, delay;
  boolean lastDirection; // false - left, true - right
  boolean isJump;
  boolean isOnPlatform;
  int jumpSpeed;
  int gravity;
  int changeX, changeY;
  boolean isGravity;
  
  // Constructor
  Player() {
    currentFrameWalking = currentFrameJumping = 0;
    delay = 1;
    isJump = false;
    isOnPlatform = false;
    lastDirection = true;
    gravity = 6;
    jumpSpeed = 40;
    isGravity = true;
    
    // Ccale of the player
    w = 80;
    h = 64;
    
    // Ctarting position
    x = width/2;
    y = height/2;
    posLeft = x - w/4;
    posRight = x + w/4;
    posTop = y - h/2;
    posBottom = y + h/2;
    
    maxSpeed = 8;
    changeX = 0;
    changeY = gravity;
  }
  
  // METHODS
  
  // Get the boundary positions of the sprite
  public int getLeft () {
    return posLeft;
  }
  public int getRight () {
    return posRight;
  }
  public int getTop () {
    return posTop;
  }
  public int getBottom () {
    return posBottom;
  }
  
  public void setChangeX (int x) {
    changeX = x;
  }
  
  public void setChangeY (int y) {
    changeY = y;
  }
  
  public void changePositionX () {
    cameraOffsetX -= changeX;
  }
  
  public void changePositionY () {
    cameraOffsetY -= changeY;
  }
  
  public void display() {
    
    --delay;
    if (delay == 0) {
      currentFrameWalking = ++currentFrameWalking % numberWalkingImages;
      currentFrameJumping = ++currentFrameJumping % numberJumpingImages;
      delay = 5;
    }
    
    if (isHurt) {
      isHurt = (hurt > 0)? true : false;
      --hurt;
    }
    
    if ( (hurt%20 > 10) && (hurt%20 < 20 )) {
      rectMode(CENTER);
      color(41, 44, 71);
      rect(-x, y, w, h);
    }
    else {
    if (isJump && !lastDirection) {
      pushMatrix();
      scale(-1, 1);
      imageMode(CENTER);
      image(jumpingImages[currentFrameJumping], -x, y, w, h);
      popMatrix();
    }
    else if (isJump && lastDirection) {
      imageMode(CENTER);
      image(jumpingImages[currentFrameJumping], x, y, w, h);
    }
    else if (left) {
      pushMatrix();
      scale(-1, 1);
      imageMode(CENTER);
      image(walkingImages[currentFrameWalking], -x, y, w, h);
      popMatrix();
    }
    else if (right) {
      imageMode(CENTER);
      image(walkingImages[currentFrameWalking], x, y, w, h);
    }
    else if (!lastDirection) {
      pushMatrix();
      scale(-1, 1);
      imageMode(CENTER);
      image(walkingImages[standingImage], -x, y, w, h);
      popMatrix();
    }
    else {
      imageMode(CENTER);
      image(walkingImages[standingImage], x, y, w, h);
    }
    
  }
    
  }
  
  
  public boolean checkCollision (Object tile, String side) {
      
    int rightDx = tile.getLeft() - getRight();
    int leftDx = getLeft() - tile.getRight();
    int topDy = getTop() - tile.getBottom();
    int bottomDy = tile.getTop() - getBottom();
    
     boolean noXOverlap = getRight() <= tile.getLeft() || getLeft() >= tile.getRight();
     boolean noYOverlap = getBottom() <= tile.getTop() || getTop() >= tile.getBottom();
     
     if (noXOverlap || noYOverlap) {
       return false;
     }
     else {
        if (side == "BOTTOM") {
            tile.dy = bottomDy-2;
            return true;
        }
        else if (side == "TOP") {
            tile.dy = -topDy+2;
            return true;
        }
        else if (side == "LEFT") {
            tile.dx = -leftDx;
            return true;
        }
        else if (side == "RIGHT") {
            tile.dx = rightDx;
            return true;
        }
       return true;
     }
  }
  
  public boolean checkifOnPlatform (Object tile) {
    
     boolean noXOverlap = getRight() <= tile.getLeft() || getLeft() >= tile.getRight();
     boolean noYOverlap = getBottom()+4 <= tile.getTop() || getTop() >= tile.getBottom();
     
     if (noXOverlap || noYOverlap) {
       return false;
     }
     else {
       if (!(noXOverlap || noYOverlap))
         return true;
     }
     return false;

  }
  
  public ArrayList<Object> checkCollisionList (Object objects[], int objectsNumber, String side) {
    
    Object tile;
    ArrayList<Object> collisionList = new ArrayList<Object>();
    
    if (side == "PLATFORM") {
      for (int i = 0; i < objectsNumber; ++i) {
        tile = objects[i];
        if (tile.id == -1) {
          continue;
        }
        if (checkifOnPlatform(tile) == true) {
          collisionList.add(tile);
        }
      }
    }
    else {
      for (int i = 0; i < objectsNumber; ++i) {
        tile = objects[i];
        if (tile.id == -1) {
          continue;
        }
        if (checkCollision(tile, side) == true) {
          if (tile.id == 22) {
            ++points;
            if (levelState == "LEVEL 1") {
              worldLevel1.deleteTile(tile);
            }
            else if (levelState == "LEVEL 2") {
              worldLevel2.deleteTile(tile);
            }
            else if (levelState == "LEVEL 3") {
              worldLevel2.deleteTile(tile);
            }
          }
          else if ((tile.id == 25) || (tile.id == 26)) {
            if (!doNotChangeLevel) {
              if (levelState == "LEVEL 1") {
                levelState = "LEVEL 2";
                doNotChangeLevel = true;
                break;
              }
              else if (levelState == "LEVEL 2") {
                levelState = "LEVEL 3";
                doNotChangeLevel = true;
                break;
              }
              else if (levelState == "LEVEL 3") {
                levelState = "WON";
                doNotChangeLevel = true;
                break;
              }
            }
          }
          else if (tile.id == 27) {
            if (livesLeft == 0) {
              levelState = "LOST";
            }
            else {
              isHurt = true;
              hurt = 100;
              if (isHurt)
                --livesLeft;
            }
          }
          else
            collisionList.add(tile);
        }
      }
    }
    
    return collisionList;
 
  }

  public void resolvePlatformCollisions (Object objects[], int objectsNumber) {
    
    ArrayList<Object> collisionList;
    
    // Moving to the left side
    if (left) {
      collisionList = checkCollisionList(objects, objectsNumber, "LEFT");
      // resolving collisions
      if (collisionList.size() > 0 && !lastDirection) {
        Object collided = collisionList.get(0);
        if (collided.dx > 0) {
          setChangeX(collided.dx);
          changePositionX();
          setChangeX(0);
        }
        else {
        setChangeX(-maxSpeed);
        changePositionX();
        }
      }
      else {
        setChangeX(-maxSpeed);
        changePositionX();
      }
      lastDirection = false;
    }
    // Moving to the right side
    else if (right) {
      collisionList = checkCollisionList(objects, objectsNumber, "RIGHT");
      // resolving collisions
      if (collisionList.size() > 0 && lastDirection) {
        Object collided = collisionList.get(0);
        if (collided.dx < 0) {
          setChangeX(collided.dx);
          changePositionX();
        }
        else {
        setChangeX(maxSpeed);
        changePositionX();
        }
      }
      else {
        setChangeX(maxSpeed);
        changePositionX();
      }
      lastDirection = true;
    }
    // If moving neither to Left or Right
    if (!left && !right) {
      setChangeX(0);
    }
    
    if (changeY > 0) {
      collisionList = checkCollisionList(objects, objectsNumber, "BOTTOM");
      // resolving collisions
        if (collisionList.size() > 0) {
          Object collided = collisionList.get(0);
          if (collided.dy < 0) {
            setChangeY(collided.dy);
            changePositionY();
            setChangeY(0);
          }
        }
        else if (!isJump && !isOnPlatform) {
          setChangeY(gravity);
          changePositionY();
          isOnPlatform = false;
        }
    }
    
    if (changeY == 0) {       
      collisionList = checkCollisionList(objects, objectsNumber, "PLATFORM");
      // resolving collisions
        if (collisionList.size() > 0) {
          isOnPlatform = true;
        }
        else {
          isOnPlatform = false;
          setChangeY(gravity);
        }
    }
    
    // JUMPING
    if (up && !isJump && isOnPlatform) {
      isJump = true;
      isOnPlatform = false;
    }
    
    if (isJump == true) {
      if (jumpSpeed >= -30) {
        setChangeY(-jumpSpeed);
        changePositionY();
        jumpSpeed -= gravity;
      }
      else {
        isJump = false;
        jumpSpeed = 30;
      }
    }
    
    if (!isHurt) {
    for (int i = 0; i < woltBoxesNumber; ++i) {
      if (woltBoxes[i].isTouching(corgi) == true) {
        isHurt = true;
        hurt = 100;
        if (isHurt)
        --livesLeft;
       }
      }
    }
    if (livesLeft <= 0) {
      levelState = "LOST";
    }
    

    }
  
}
  public void settings() {  size(1000,700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "boltGame" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
